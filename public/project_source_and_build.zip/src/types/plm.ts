export type VersionStatus = 'DRAFT' | 'PENDING_REVIEW' | 'PUBLISHED' | 'REJECTED' | 'OBSOLETE';

export type FileType = 'PDF' | 'DWG' | 'STEP' | 'IMAGE' | 'DXF' | 'IGES' | string;

export interface DrawingFile {
  id: string;
  fileName: string;
  fileType: FileType;
  fileSize: number; // in bytes
  fileHash: string;
  uploadTime: string;
  uploader: string;
  previewUrl?: string;
  sheetCount?: number;
  cadLayers?: string[];
}

export interface VersionLog {
  id: string;
  timestamp: string;
  operator: string;
  action: string;
  details: string;
}

export interface DrawingVersion {
  id: string;
  drawingNo: string;
  versionNo: string; // e.g. "V1", "V2"
  status: VersionStatus;
  isActive: boolean; // 是否启用 (true: 已启用, false: 已停用)
  isDefault?: boolean; // 是否默认版本
  publishTime?: string;
  publisher?: string;
  reviewer?: string;
  reviewTime?: string;
  notes?: string;
  changeDesc?: string;
  ecoNumber?: string;
  updatedAt?: string;
  files: DrawingFile[];
  logs?: VersionLog[]; // 每个版本的操作变更日志
  createdAt: string;
  createdBy: string;
}

export interface DrawingMaster {
  id: string;
  drawingNo: string;
  materialId: string;
  materialCode: string;
  materialName: string;
  materialSpec: string;
  category: string;
  currentPublishedVersion?: string;
  latestVersion: string;
  versions: DrawingVersion[];
  createdAt: string;
  updatedAt: string;
}

export interface Material {
  id: string;
  materialCode: string;
  materialName: string;
  materialSpec: string;
  category: string;
  unit: string;
  drawingNo?: string;
  hasDrawing: boolean;
  status: 'ACTIVE' | 'DISABLED';
  createdAt: string;
  updatedAt: string;
  remarks?: string;
}

export type BOMStatus = 'DRAFT' | 'PENDING' | 'PENDING_REVIEW' | 'PUBLISHED' | 'REJECTED' | 'FROZEN' | 'OBSOLETE';

export interface BOMVersionInfo {
  id: string;
  versionNo: string;
  status: BOMStatus;
  creator: string;
  updateTime: string;
  isDefault: boolean;
  isCurrent?: boolean;
  notes?: string;
  itemsCount?: number;
}

export interface BOMCategory {
  id: string;
  name: string;
  count?: number;
  children?: BOMCategory[];
}

export interface BOMStructureNode {
  id: string;
  materialCode: string;
  materialName: string;
  businessAttr?: string; // 销售、采购、自制
  versionNo?: string;
  image?: string;
  category: string;
  spec: string;
  brand?: string;
  stock?: number;
  unit: string;
  standardQty: number;
  standardCost?: number;
  route?: string; // 钣金工艺路线、车床路线等
  level: number;
  parentId?: string;
  drawingNo?: string;
  drawingVersionNo?: string;
  children?: BOMStructureNode[];
}

export interface BOMDrawingLink {
  id: string;
  drawingNo: string;
  fileName: string;
  fileType: FileType;
  fileSize?: number;
  materialCode: string;
  materialName: string;
  category: string;
  updateTime: string;
  previewUrl?: string;
  versionNo?: string;
  sourceType?: 'CURRENT_MATERIAL' | 'SUB_MATERIAL' | 'PRODUCT_ROOT';
  relationPath?: string;
  level?: number;
}

export interface BOMOperationLog {
  id: string;
  bomId: string;
  versionNo: string;
  opType: 'CREATE' | 'UPGRADE' | 'STRUCTURE_UPDATE' | 'ITEM_ADD' | 'ITEM_DELETE' | 'QTY_CHANGE' | 'SET_DEFAULT' | 'SUBMIT_AUDIT' | 'AUDIT_APPROVE' | 'AUDIT_REJECT' | 'DRAWING_BIND' | 'PROPERTY_UPDATE';
  opTypeName: string;
  title: string;
  details: string;
  operator: string;
  timestamp: string;
  ip?: string;
  oldVal?: string;
  newVal?: string;
}

export interface BOMItem {
  id: string;
  materialId: string;
  materialCode: string;
  materialName: string;
  materialSpec: string;
  quantity: number;
  unit: string;
  drawingNo?: string;
  drawingVersionId?: string;
  versionNo?: string;
  versionStatus?: VersionStatus;
  isActiveVersion?: boolean;
  sortOrder?: number;
  businessAttr?: string;
  coverImage?: string;
  category?: string;
  brand?: string;
  stock?: number;
  standardCost?: number;
  routing?: string;
  scrapRate?: number;
  remark?: string;
}

export interface BOM {
  id: string;
  bomCode: string;
  name: string;
  versionNo: string;
  productCode: string;
  productName: string;
  specName?: string;
  unit?: string;
  drawingNo?: string;
  drawingVersionNo?: string;
  isDefault?: boolean;
  status: BOMStatus;
  preFreezeStatus?: BOMStatus;
  mechanicalOwner?: string;
  electricalOwner?: string;
  remark?: string;
  category?: string;
  items: BOMItem[];
  versions?: BOMVersionInfo[];
  structureTree?: BOMStructureNode[];
  drawings?: BOMDrawingLink[];
  operationLogs?: BOMOperationLog[];
  createdAt: string;
  updatedAt: string;
  updatedBy: string;
}

export interface SalesOrder {
  id: string;
  orderNo: string;
  workOrderNo?: string;
  customerName: string;
  productCode: string;
  productName: string;
  productSpec: string;
  bomId: string;
  bomCode: string;
  bomVersion: string;
  orderQuantity: number;
  deliveryDate: string;
  status: 'IN_PRODUCTION' | 'PENDING' | 'COMPLETED';
}

export interface DrawingArchiveItem {
  id: string;
  materialId: string;
  materialCode: string;
  materialName: string;
  materialSpec: string;
  drawingNo: string;
  drawingVersionId: string;
  versionNo: string;
  fileTypes: FileType[];
  selectedForArchive: boolean;
}

export interface DrawingArchiveSnapshot {
  id: string;
  archiveNo: string;
  orderNo: string;
  customerName: string;
  productCode: string;
  productName: string;
  bomCode: string;
  bomVersion: string;
  archivedAt: string;
  archivedBy: string;
  snapshotItems: DrawingArchiveItem[];
  sealHash: string; // 防篡改数字指纹
  status: 'LOCKED';
  notes?: string;
}

export interface ImportCandidate {
  id: string;
  rawFileName: string;
  fileSize: number;
  fileHash: string;
  parsedName: string;
  parsedSpec: string;
  parsedDrawingNo?: string;
  parsedFileType: FileType;
  matchStatus: 'MATCHED' | 'UNMATCHED' | 'PARSE_ERROR' | 'DUPLICATE_HASH';
  matchedMaterialId?: string;
  matchedMaterialCode?: string;
  matchedMaterialName?: string;
  matchedMaterialSpec?: string;
  matchedDrawingNo?: string;
  existingDraftVersionId?: string;
  hasExistingDraft: boolean;
  resolutionAction: 'CREATE_MASTER_AND_DRAFT_V1' | 'NEW_DRAFT_NEXT_VER' | 'MERGE_TO_EXISTING_DRAFT' | 'SKIP_DUPLICATE' | 'MANUAL_BIND';
  targetDraftVersionId?: string; // 用户具体指定的草稿版本 ID
  manualMaterialId?: string;
  errorMessage?: string;
  selected: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  level: 'INFO' | 'WARN' | 'GUARD_BLOCK' | 'SUCCESS';
  guardType: 'MATERIAL_ID_UNIQUE' | 'DRAWING_NO_UNIQUE' | 'VERSION_UNIQUE' | 'HASH_DEDUPLICATION' | 'IMMUTABLE_PUBLISHED' | 'REF_VALIDATION_ACTIVE_ONLY' | 'DEFAULT_VERSION_SET';
  title: string;
  description: string;
  operator: string;
  targetEntity: string;
}

export interface PendingQuestionItem {
  id: string;
  code: string;
  question: string;
  suggestedRole: string;
  currentStatus: 'PENDING' | 'CONFIRMED' | 'IN_DISCUSSION';
  consensusValue?: string;
  notes?: string;
}
