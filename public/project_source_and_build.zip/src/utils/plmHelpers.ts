import { FileType, VersionStatus, Material, DrawingMaster } from '../types/plm';

export interface ParsedFileNameResult {
  isValid: boolean;
  materialName?: string;
  materialSpec?: string;
  drawingNo?: string;
  fileType?: FileType;
  rawExtension?: string;
  errorMessage?: string;
}

export function parseDrawingFileName(fileName: string): ParsedFileNameResult {
  if (!fileName || !fileName.includes('.')) {
    return { isValid: false, errorMessage: '文件名缺少有效格式扩展名' };
  }

  const lastDotIndex = fileName.lastIndexOf('.');
  const ext = fileName.substring(lastDotIndex + 1).toUpperCase();
  const nameWithoutExt = fileName.substring(0, lastDotIndex);

  let fileType: FileType = 'PDF';
  if (ext === 'PDF') fileType = 'PDF';
  else if (ext === 'DWG' || ext === 'DXF') fileType = 'DWG';
  else if (ext === 'STEP' || ext === 'STP' || ext === 'IGES' || ext === 'IGS') fileType = 'STEP';
  else if (['PNG', 'JPG', 'JPEG', 'WEBP', 'SVG'].includes(ext)) fileType = 'IMAGE';
  else {
    return { isValid: false, rawExtension: ext, errorMessage: `不支持的文件格式: .${ext}（支持 PDF, DWG, STEP, 图片）` };
  }

  // 尝试以下划线分割
  const parts = nameWithoutExt.split('_');
  if (parts.length < 2) {
    return {
      isValid: false,
      fileType,
      rawExtension: ext,
      errorMessage: '文件名未遵循规范（需至少包含：物料名称_规格型号_文件类型）',
    };
  }

  // 模式1: 推荐要求 物料名称_规格型号_图号_文件类型
  // 例如: 电气安装盒_G14_X0610-C004-G14_PDF
  if (parts.length >= 4) {
    return {
      isValid: true,
      materialName: parts[0].trim(),
      materialSpec: parts[1].trim(),
      drawingNo: parts[2].trim(),
      fileType,
      rawExtension: ext,
    };
  }

  // 模式2: 最低要求 物料名称_规格型号_文件类型
  // 例如: 电气安装盒_G14_PDF
  if (parts.length === 3) {
    return {
      isValid: true,
      materialName: parts[0].trim(),
      materialSpec: parts[1].trim(),
      drawingNo: undefined,
      fileType,
      rawExtension: ext,
    };
  }

  // 模式3: 降级尝试 物料名称_规格型号
  if (parts.length === 2) {
    return {
      isValid: true,
      materialName: parts[0].trim(),
      materialSpec: parts[1].trim(),
      drawingNo: undefined,
      fileType,
      rawExtension: ext,
    };
  }

  return { isValid: false, errorMessage: '无法解析文件名结构' };
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function getStatusBadge(status: VersionStatus | string) {
  switch (status) {
    case 'DRAFT':
      return {
        label: '草稿',
        className: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700',
        dotColor: 'bg-slate-400',
      };
    case 'PENDING_REVIEW':
    case 'PENDING':
      return {
        label: '待审批',
        className: 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-800',
        dotColor: 'bg-amber-500 animate-pulse',
      };
    case 'PUBLISHED':
    case 'APPROVED':
      return {
        label: '已发布',
        className: 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800',
        dotColor: 'bg-blue-500',
      };
    case 'REJECTED':
      return {
        label: '驳回',
        className: 'bg-red-50 text-red-700 dark:bg-red-950/60 dark:text-red-300 border border-red-200 dark:border-red-800',
        dotColor: 'bg-red-500',
      };
    case 'OBSOLETE':
      return {
        label: '已作废',
        className: 'bg-slate-200 text-slate-500 dark:bg-slate-800 dark:text-slate-500 border border-slate-300 dark:border-slate-700',
        dotColor: 'bg-slate-400',
      };
    default:
      return {
        label: '草稿',
        className: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700',
        dotColor: 'bg-slate-400',
      };
  }
}

export function detectFileTypeFromName(fileName: string): string {
  if (!fileName || !fileName.includes('.')) return 'OTHER';
  const ext = fileName.split('.').pop()?.toUpperCase() || 'FILE';
  if (ext === 'PDF') return 'PDF';
  if (ext === 'DWG') return 'DWG';
  if (ext === 'DXF') return 'DXF';
  if (ext === 'STEP' || ext === 'STP') return 'STEP';
  if (ext === 'IGES' || ext === 'IGS') return 'IGES';
  if (['PNG', 'JPG', 'JPEG', 'WEBP', 'SVG', 'BMP', 'GIF', 'TIFF'].includes(ext)) return 'IMAGE';
  if (['SLDPRT', 'SLDASM', 'PRT', 'IPT', 'CATPART', 'CATPRODUCT', 'X_T', 'X_B', 'PARASOLID'].includes(ext)) return ext;
  return ext;
}

export function getFileTypeBadge(fileType: FileType) {
  const ft = (fileType || '').toUpperCase();
  switch (ft) {
    case 'PDF':
      return {
        label: 'PDF 矢量工程图',
        short: 'PDF',
        color: 'text-red-600 bg-red-50 border-red-200 dark:bg-red-950/40 dark:text-red-300 dark:border-red-800',
      };
    case 'DWG':
      return {
        label: 'AutoCAD DWG 二维图',
        short: 'DWG',
        color: 'text-blue-600 bg-blue-50 border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800',
      };
    case 'DXF':
      return {
        label: 'DXF 二维交换格式',
        short: 'DXF',
        color: 'text-cyan-600 bg-cyan-50 border-cyan-200 dark:bg-cyan-950/40 dark:text-cyan-300 dark:border-cyan-800',
      };
    case 'STEP':
    case 'STP':
      return {
        label: 'STEP 三维实体模型',
        short: 'STEP',
        color: 'text-violet-600 bg-violet-50 border-violet-200 dark:bg-violet-950/40 dark:text-violet-300 dark:border-violet-800',
      };
    case 'IGES':
    case 'IGS':
      return {
        label: 'IGES 三维曲面模型',
        short: 'IGES',
        color: 'text-purple-600 bg-purple-50 border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800',
      };
    case 'SLDPRT':
    case 'PRT':
    case 'IPT':
    case 'CATPART':
      return {
        label: 'SolidWorks 零件三维图',
        short: 'SLDPRT',
        color: 'text-rose-600 bg-rose-50 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800',
      };
    case 'SLDASM':
    case 'ASM':
    case 'CATPRODUCT':
      return {
        label: 'SolidWorks 装配体文件',
        short: 'SLDASM',
        color: 'text-indigo-600 bg-indigo-50 border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-300 dark:border-indigo-800',
      };
    case 'IMAGE':
    case 'PNG':
    case 'JPG':
    case 'JPEG':
    case 'WEBP':
    case 'SVG':
      return {
        label: '渲染图/图片',
        short: 'IMG',
        color: 'text-emerald-600 bg-emerald-50 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
      };
    default:
      return {
        label: `${ft} 文件`,
        short: ft || 'FILE',
        color: 'text-amber-600 bg-amber-50 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
      };
  }
}

export function copyToClipboard(text: string): Promise<boolean> {
  return navigator.clipboard.writeText(text)
    .then(() => true)
    .catch(() => false);
}

export function generateNextVersionNo(existingVersions: string[]): string {
  if (!existingVersions || existingVersions.length === 0) return 'V1';
  const nums = existingVersions
    .map(v => {
      const match = v.match(/\d+/);
      return match ? parseInt(match[0], 10) : 0;
    })
    .filter(n => !isNaN(n));
  const max = nums.length > 0 ? Math.max(...nums) : 0;
  return `V${max + 1}`;
}
